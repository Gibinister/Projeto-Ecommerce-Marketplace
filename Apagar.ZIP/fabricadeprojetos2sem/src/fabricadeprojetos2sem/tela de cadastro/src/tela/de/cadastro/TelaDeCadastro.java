package tela.de.cadastro;





public class TelaDeCadastro {

    public static void main(String[] args) {
        
    }
    
}
